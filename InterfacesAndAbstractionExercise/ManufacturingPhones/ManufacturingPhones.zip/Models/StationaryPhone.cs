﻿using ManufacturingPhones.Interfaces;
using ManufacturingPhones.InvalidExceptions;
using System;
using System.Linq;

namespace ManufacturingPhones.Models
{
    public class StationaryPhone : ICalling
    {
        public string Call(string phoneNumber)
        {
            if (!phoneNumber.All(x => char.IsDigit(x)))
            {
                throw new InvalidPhoneNumberException();
            }
            return $"Dialing... {phoneNumber}";
        }
    }
}
