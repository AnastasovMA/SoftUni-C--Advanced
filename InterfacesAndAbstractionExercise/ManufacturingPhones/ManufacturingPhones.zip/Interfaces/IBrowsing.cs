﻿namespace ManufacturingPhones.Interfaces
{
    public interface IBrowsing
    {
        public string Browse(string url);
    }
}
