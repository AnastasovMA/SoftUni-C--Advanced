﻿namespace ManufacturingPhones.Interfaces
{
    public interface ICalling
    {
        public string Call(string phoneNumber);
    }
}
